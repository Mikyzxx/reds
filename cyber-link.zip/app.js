// CYBER-LINK // CORE LOGIC & TELEMETRY SYSTEMS

// --- AUDIO SYNTHESIZER (Web Audio API) ---
class CyberSynth {
  constructor() {
    this.ctx = null;
    this.masterVolume = 0.3; // Default master volume (scaled by slider)
  }

  init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  setVolume(vol) {
    this.masterVolume = vol / 100;
  }

  // Play a cybernetic sweep when connecting
  playConnect() {
    this.init();
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(150, now);
    // Futuristic exponential sweep up
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.4);
    osc.frequency.exponentialRampToValueAtTime(1200, now + 0.6);
    
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(this.masterVolume * 0.5, now + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
    
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    
    osc.start(now);
    osc.stop(now + 0.7);

    // Second chime chord
    setTimeout(() => {
      const osc2 = this.ctx.createOscillator();
      const gain2 = this.ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(1200, this.ctx.currentTime);
      gain2.gain.setValueAtTime(0, this.ctx.currentTime);
      gain2.gain.linearRampToValueAtTime(this.masterVolume * 0.4, this.ctx.currentTime + 0.05);
      gain2.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.5);
      
      osc2.connect(gain2);
      gain2.connect(this.ctx.destination);
      osc2.start();
      osc2.stop(this.ctx.currentTime + 0.5);
    }, 150);
  }

  // Play a reverse sweep when disconnecting
  playDisconnect() {
    this.init();
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    
    osc.type = 'sine';
    osc.frequency.setValueAtTime(600, now);
    osc.frequency.linearRampToValueAtTime(80, now + 0.5);
    
    gain.gain.setValueAtTime(this.masterVolume * 0.6, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
    
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    
    osc.start(now);
    osc.stop(now + 0.55);
  }

  // Play digital click/beep for toggling mute/unmute
  playToggle(isActivated) {
    this.init();
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(isActivated ? 880 : 440, now);
    osc.frequency.setValueAtTime(isActivated ? 1200 : 330, now + 0.05);
    
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(this.masterVolume * 0.4, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
    
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    
    osc.start(now);
    osc.stop(now + 0.15);
  }

  // Play a soft synth chirp for incoming messages
  playMessage() {
    this.init();
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    
    osc.type = 'sine';
    osc.frequency.setValueAtTime(784, now); // G5
    osc.frequency.setValueAtTime(987, now + 0.08); // B5
    
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(this.masterVolume * 0.3, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
    
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    
    osc.start(now);
    osc.stop(now + 0.3);
  }
}

const synth = new CyberSynth();

// --- STATE MANAGEMENT ---
const state = {
  username: "Usuario_Quantum",
  roomCode: "VOID-LINK",
  localStream: null,
  isMuted: false,
  isCamOff: false,
  isScreenSharing: false,
  participants: {}, // key: peerId, value: participant object
  bots: {}, // key: botId, value: bot participant info
  broadcastChannel: null,
  peerConnections: {}, // key: peerId, value: RTCPeerConnection
  myId: Math.random().toString(36).substring(2, 9),
  isDemoMode: false,
  audioContext: null,
  localAnalyser: null,
  userColor: '#00f3ff'
};

// Available bots definition
const BOT_TEMPLATES = [
  { id: 'bot-aegis', name: 'A.E.G.I.S // CORE_AI', tag: 'AI_NODE', color: '#b100ff', letter: 'A' },
  { id: 'bot-kronos', name: 'KRONOS // COMM_GRID', tag: 'RELAY_BOT', color: '#ff007f', letter: 'K' },
  { id: 'bot-helios', name: 'HELIOS // ORBIT_LINK', tag: 'SATELLITE', color: '#ffea00', letter: 'H' },
  { id: 'bot-neural', name: 'NEURAL // MATRIX_NODE', tag: 'VIRTUAL', color: '#00ff66', letter: 'N' }
];

// Fallback background matrix animation
let fallbackCanvasInterval = null;

// --- DOM ELEMENTS ---
const joinScreen = document.getElementById('join-screen');
const appShell = document.getElementById('app-shell');
const usernameInput = document.getElementById('username-input');
const roomInput = document.getElementById('room-input');
const joinCallBtn = document.getElementById('join-call-btn');
const quickDemoBtn = document.getElementById('quick-demo-btn');
const activeRoomCode = document.getElementById('active-room-code');
const participantsGrid = document.getElementById('participants-grid');
const chatMessages = document.getElementById('chat-messages');
const chatInput = document.getElementById('chat-input');
const chatSendBtn = document.getElementById('chat-send-btn');
const userDisplayName = document.getElementById('user-display-name');
const btnToggleMic = document.getElementById('btn-toggle-mic');
const btnToggleCam = document.getElementById('btn-toggle-cam');
const btnToggleScreen = document.getElementById('btn-toggle-screen');
const btnDisconnect = document.getElementById('btn-disconnect');
const btnToggleSidebar = document.getElementById('btn-toggle-sidebar');
const volSlider = document.getElementById('vol-slider');
const sidebar = document.getElementById('sidebar');

// Icons
const iconMic = document.getElementById('icon-mic');
const iconMicOff = document.getElementById('icon-mic-off');
const iconCam = document.getElementById('icon-cam');
const iconCamOff = document.getElementById('icon-cam-off');

// Connection Node
const connectionDot = document.getElementById('connection-dot');
const connectionLabel = document.getElementById('connection-label');

// --- BOT INJECTION & REMOVAL ---
document.getElementById('sim-add-bot-btn').addEventListener('click', () => {
  const currentBotCount = Object.keys(state.bots).length;
  if (currentBotCount >= BOT_TEMPLATES.length) {
    addSystemMessage("Límite de nodos bot alcanzado en la telemetría.");
    return;
  }
  const nextTemplate = BOT_TEMPLATES[currentBotCount];
  injectBot(nextTemplate);
});

document.getElementById('sim-remove-bot-btn').addEventListener('click', () => {
  const botKeys = Object.keys(state.bots);
  if (botKeys.length === 0) return;
  const botIdToRemove = botKeys[botKeys.length - 1];
  removeBot(botIdToRemove);
});

document.getElementById('sim-webrtc-info').addEventListener('click', () => {
  addSystemMessage("INFO CONEXIÓN: Abre este enlace en otra pestaña/navegador en tu misma PC. Ingresa el mismo código de canal (" + state.roomCode + ") para establecer un videoenlace WebRTC real.");
});

// Tab headers
const tabs = document.querySelectorAll('.sidebar-tab');
tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(tab.getAttribute('data-tab')).classList.add('active');
    synth.playToggle(true);
  });
});

// Sidebar Toggle
btnToggleSidebar.addEventListener('click', () => {
  sidebar.classList.toggle('collapsed');
  synth.playToggle(true);
});

// --- AUDIO INITIALIZATION ---
function initAudioAnalyser(stream) {
  try {
    state.audioContext = new (window.AudioContext || window.webkitAudioContext)();
    state.localAnalyser = state.audioContext.createAnalyser();
    state.localAnalyser.fftSize = 64;
    const source = state.audioContext.createMediaStreamSource(stream);
    source.connect(state.localAnalyser);
    drawLocalMicVisualizer();
  } catch (err) {
    console.warn("Could not construct local Web Audio Analyser: ", err);
  }
}

// Draw local mic visualizer (bottom-left)
function drawLocalMicVisualizer() {
  const canvas = document.getElementById('user-mic-visualizer');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const bufferLength = state.localAnalyser ? state.localAnalyser.frequencyBinCount : 16;
  const dataArray = new Uint8Array(bufferLength);

  function draw() {
    requestAnimationFrame(draw);
    if (!canvas) return;
    
    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    if (state.isMuted) {
      // Draw flat line
      ctx.strokeStyle = '#ff007f';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, height / 2);
      ctx.lineTo(width, height / 2);
      ctx.stroke();
      return;
    }

    if (state.localAnalyser) {
      state.localAnalyser.getByteFrequencyData(dataArray);
    } else {
      // Sim audio waves if analyser is not loaded
      for (let i = 0; i < bufferLength; i++) {
        dataArray[i] = Math.random() * 30 + (Math.sin(Date.now() / 200 + i) * 10);
      }
    }

    const barWidth = (width / bufferLength) * 1.5;
    let barHeight;
    let x = 0;

    for (let i = 0; i < bufferLength; i++) {
      barHeight = (dataArray[i] / 255) * height;
      
      // Draw neon bar
      ctx.fillStyle = `rgba(0, 243, 255, ${0.4 + (barHeight/height)})`;
      ctx.fillRect(x, height - barHeight, barWidth - 1, barHeight);

      // Glow cap
      ctx.fillStyle = '#00f3ff';
      ctx.fillRect(x, height - barHeight, barWidth - 1, 2);
      
      x += barWidth;
    }
  }
  draw();
}

// --- TELEMETRY GRAPHICS (Sidebar Graphs) ---
const graphs = {
  latency: {
    canvas: document.getElementById('latency-graph'),
    history: Array(40).fill(12),
    color: '#b100ff',
    label: 'ms',
    draw: null
  },
  bandwidth: {
    canvas: document.getElementById('bandwidth-graph'),
    history: Array(40).fill(12.5),
    color: '#00f3ff',
    label: 'Mbps',
    draw: null
  }
};

function initTelemetryGraphs() {
  Object.keys(graphs).forEach(key => {
    const graph = graphs[key];
    if (!graph.canvas) return;
    const ctx = graph.canvas.getContext('2d');
    
    // Auto-resize canvas buffer
    graph.canvas.width = graph.canvas.parentElement.clientWidth;
    graph.canvas.height = graph.canvas.parentElement.clientHeight;

    graph.draw = function() {
      if (!graph.canvas) return;
      const width = graph.canvas.width;
      const height = graph.canvas.height;
      ctx.clearRect(0, 0, width, height);

      // Draw Grid lines
      ctx.strokeStyle = 'rgba(0, 243, 255, 0.05)';
      ctx.lineWidth = 1;
      
      // Vertical lines
      for (let x = 0; x < width; x += 30) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      // Horizontal lines
      for (let y = 0; y < height; y += 20) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Draw line graph
      ctx.beginPath();
      const points = graph.history;
      const maxVal = Math.max(...points, 20); // Scale relative to max or baseline
      const step = width / (points.length - 1);

      ctx.moveTo(0, height - (points[0] / maxVal) * (height - 10) - 5);
      for (let i = 1; i < points.length; i++) {
        const px = i * step;
        const py = height - (points[i] / maxVal) * (height - 10) - 5;
        ctx.lineTo(px, py);
      }

      // Stroke styles
      ctx.strokeStyle = graph.color;
      ctx.lineWidth = 2;
      ctx.shadowColor = graph.color;
      ctx.shadowBlur = 8;
      ctx.stroke();
      
      // Gradient fill under graph
      ctx.shadowBlur = 0;
      ctx.lineTo(width, height);
      ctx.lineTo(0, height);
      ctx.closePath();
      const grad = ctx.createLinearGradient(0, 0, 0, height);
      grad.addColorStop(0, graph.color + '15');
      grad.addColorStop(1, 'transparent');
      ctx.fillStyle = grad;
      ctx.fill();
    };
  });

  // Regular updates to simulation metrics
  setInterval(() => {
    // Latency fluctuation
    const latBase = state.isDemoMode ? 24 : 12;
    const nextLat = Math.max(5, Math.floor(latBase + (Math.random() * 8 - 4)));
    graphs.latency.history.shift();
    graphs.latency.history.push(nextLat);
    document.getElementById('stat-latency').innerText = `${nextLat} ms`;

    // Bandwidth fluctuation
    const baseTx = state.isScreenSharing ? 25.4 : 12.1;
    const rxMultiplier = 1 + (Object.keys(state.participants).length + Object.keys(state.bots).length) * 0.8;
    const nextRx = (20.5 * rxMultiplier + (Math.random() * 4 - 2)).toFixed(1);
    const nextTx = (baseTx + (Math.random() * 2 - 1)).toFixed(1);
    
    graphs.bandwidth.history.shift();
    graphs.bandwidth.history.push(parseFloat(nextRx));
    
    document.getElementById('stat-rx').innerText = `${nextRx} Mbps`;
    document.getElementById('stat-tx').innerText = `${nextTx} Mbps`;
    document.getElementById('stat-packetloss').innerText = `${(0.01 + Math.random() * 0.04).toFixed(3)}%`;

    // Render updated statistics graphs
    if (graphs.latency.draw) graphs.latency.draw();
    if (graphs.bandwidth.draw) graphs.bandwidth.draw();
  }, 1000);
}

// Window resizing adjustments for graph canvas
window.addEventListener('resize', () => {
  Object.keys(graphs).forEach(key => {
    const graph = graphs[key];
    if (graph.canvas) {
      graph.canvas.width = graph.canvas.parentElement.clientWidth;
      graph.canvas.height = graph.canvas.parentElement.clientHeight;
    }
  });
});

// --- MEDIA STREAM RETRIEVAL (With Sci-Fi Matrix Fallback) ---
async function setupLocalMedia() {
  try {
    // Attempt standard webcam/mic
    state.localStream = await navigator.mediaDevices.getUserMedia({
      video: { width: 1280, height: 720, frameRate: 30 },
      audio: true
    });
    addSystemMessage("Acceso a hardware establecido. Canal de video activo.");
  } catch (err) {
    console.warn("Could not capture real camera/mic: ", err);
    addSystemMessage("ADVERTENCIA: Hardware no disponible. Generando matriz de transmisión virtual...");
    
    // Construct animated cyber-pattern canvas as placeholder video track
    const canvas = document.createElement('canvas');
    canvas.width = 640;
    canvas.height = 360;
    const ctx = canvas.getContext('2d');
    
    let frame = 0;
    fallbackCanvasInterval = setInterval(() => {
      frame++;
      // Dark cyber background
      ctx.fillStyle = '#05060b';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      // Cyber radar grid lines
      ctx.strokeStyle = 'rgba(0, 243, 255, 0.15)';
      ctx.lineWidth = 1;
      
      // Ring pulse
      ctx.beginPath();
      ctx.arc(canvas.width / 2, canvas.height / 2, (frame * 3) % 250, 0, Math.PI * 2);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(canvas.width / 2, canvas.height / 2, ((frame * 3) + 120) % 250, 0, Math.PI * 2);
      ctx.stroke();

      // Cyber telemetry code
      ctx.fillStyle = 'rgba(0, 243, 255, 0.4)';
      ctx.font = '10px Orbitron';
      ctx.fillText(`TRANSMISSION_NODE: ${state.username.toUpperCase()}`, 20, 30);
      ctx.fillText(`FREQ: 894.22 GHz`, 20, 50);
      ctx.fillText(`LINK_STATUS: DIRECT_ROUTE`, 20, 70);
      ctx.fillText(`TELEMETRIC_FPS: 30`, 20, 90);
      
      // Matrix code drop simulation
      ctx.fillStyle = 'rgba(177, 0, 255, 0.3)';
      for (let i = 0; i < 15; i++) {
        const x = i * 40 + 20;
        const y = ((frame * (2 + i % 3)) % canvas.height);
        ctx.fillText(Math.random().toString(36).substring(2, 4).toUpperCase(), x, y);
      }

      // Visual pulse dot
      ctx.fillStyle = '#00f3ff';
      ctx.beginPath();
      ctx.arc(canvas.width - 40, 30, 6, 0, Math.PI * 2);
      ctx.fill();

    }, 33); // 30 FPS

    const canvasStream = canvas.captureStream(30);
    
    // Construct synthesized silence audio track
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const dest = audioContext.createMediaStreamDestination();
    const osc = audioContext.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(0, audioContext.currentTime); // Inaudible frequency
    osc.connect(dest);
    osc.start();
    
    const combinedTracks = [
      ...canvasStream.getVideoTracks(),
      ...dest.stream.getAudioTracks()
    ];
    
    state.localStream = new MediaStream(combinedTracks);
  }

  // Create UI card for user
  createUserCard();
  initAudioAnalyser(state.localStream);
}

// Create the grid card for the user's stream
function createUserCard() {
  // Check if already exists
  let card = document.getElementById(`card-${state.myId}`);
  if (card) card.remove();

  card = document.createElement('div');
  card.id = `card-${state.myId}`;
  card.className = 'participant-card';
  card.innerHTML = `
    <video id="video-local" class="video-viewport mirrored" autoplay playsinline muted></video>
    <div id="avatar-local" class="avatar-viewport hidden">
      <div class="avatar-wrapper">
        <div class="voice-ring"></div>
        <div class="avatar-placeholder">${state.username.substring(0,2).toUpperCase()}</div>
      </div>
    </div>
    <div class="hud-overlay">
      <div class="hud-top">
        <div class="user-name-badge">
          <span>${state.username}</span>
          <span class="user-tag">(TÚ)</span>
        </div>
        <div class="hud-status-indicator">
          <div id="badge-mic-local" class="status-badge hidden">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19 11h-1.7c0 .74-.16 1.43-.43 2.05l1.23 1.23c.56-.98.9-2.09.9-3.28zm-4.02.17l-11-11L2.7 1.45 6 4.75V11c0 3.28 2.72 6 6 6 .73 0 1.43-.13 2.07-.36l3.83 3.83 1.41-1.41-14.33-14.33z"/></svg>
          </div>
        </div>
      </div>
      <div class="hud-bottom">
        <span class="user-name-badge" style="font-size: 0.65rem; border-color: var(--neon-purple); color: var(--neon-purple);">
          ENLACE LOCAL
        </span>
      </div>
    </div>
  `;
  
  participantsGrid.appendChild(card);
  
  const videoEl = card.querySelector('video');
  videoEl.srcObject = state.localStream;
  
  updateGridSize();
}

// Helper to scale layouts dynamically
function updateGridSize() {
  const cards = participantsGrid.children.length;
  participantsGrid.className = 'participant-grid';
  if (cards === 1) {
    participantsGrid.classList.add('single');
  } else if (cards === 2) {
    participantsGrid.classList.add('double');
  }
}

// --- SIGNALING & WEBRTC (BroadcastChannel Local Loopback) ---
function initBroadcastSignaling() {
  const channelName = `cyberlink-room-${state.roomCode.trim().toUpperCase()}`;
  state.broadcastChannel = new BroadcastChannel(channelName);
  
  // Event router
  state.broadcastChannel.onmessage = (event) => {
    const data = event.data;
    if (data.senderId === state.myId) return; // Ignore own echoes
    
    switch (data.type) {
      case 'peer-join':
        handlePeerJoin(data.senderId, data.username);
        break;
      case 'peer-leave':
        handlePeerLeave(data.senderId);
        break;
      case 'webrtc-offer':
        handleSdpOffer(data.senderId, data.offer, data.username);
        break;
      case 'webrtc-answer':
        handleSdpAnswer(data.senderId, data.answer);
        break;
      case 'ice-candidate':
        handleIceCandidate(data.senderId, data.candidate);
        break;
      case 'chat-broadcast':
        receiveChatMessage(data.username, data.message);
        break;
    }
  };

  // Announce presence
  state.broadcastChannel.postMessage({
    type: 'peer-join',
    senderId: state.myId,
    username: state.username
  });

  addSystemMessage(`Enlace anunciado en canal: ${state.roomCode}`);
}

async function handlePeerJoin(peerId, peerName) {
  addSystemMessage(`CONEXIÓN INTRANET: Nodo detectado (${peerName}). Iniciando protocolo WebRTC...`);
  
  // Create RTCPeerConnection
  const pc = createPeerConnection(peerId, peerName);
  state.peerConnections[peerId] = pc;

  // Add tracks
  state.localStream.getTracks().forEach(track => {
    pc.addTrack(track, state.localStream);
  });

  // Create offer
  try {
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    
    state.broadcastChannel.postMessage({
      type: 'webrtc-offer',
      senderId: state.myId,
      username: state.username,
      offer: offer
    });
  } catch (err) {
    console.error("WebRTC Offer error: ", err);
  }
}

function createPeerConnection(peerId, peerName) {
  const configuration = {
    iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
  };
  
  const pc = new RTCPeerConnection(configuration);

  pc.onicecandidate = (event) => {
    if (event.candidate) {
      state.broadcastChannel.postMessage({
        type: 'ice-candidate',
        senderId: state.myId,
        candidate: event.candidate
      });
    }
  };

  pc.ontrack = (event) => {
    const remoteStream = event.streams[0];
    createParticipantCard(peerId, peerName, remoteStream);
  };

  pc.onconnectionstatechange = () => {
    console.log(`Connection state with ${peerName}: ${pc.connectionState}`);
    if (pc.connectionState === 'connected') {
      addSystemMessage(`Enlace con ${peerName} establecido al 100%.`);
      synth.playConnect();
    } else if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed') {
      handlePeerLeave(peerId);
    }
  };

  return pc;
}

async function handleSdpOffer(peerId, offer, peerName) {
  addSystemMessage(`Oferta WebRTC recibida de ${peerName}. Resolviendo enlaces...`);
  
  let pc = state.peerConnections[peerId];
  if (!pc) {
    pc = createPeerConnection(peerId, peerName);
    state.peerConnections[peerId] = pc;
    
    // Add local tracks
    state.localStream.getTracks().forEach(track => {
      pc.addTrack(track, state.localStream);
    });
  }

  try {
    await pc.setRemoteDescription(new RTCSessionDescription(offer));
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);

    state.broadcastChannel.postMessage({
      type: 'webrtc-answer',
      senderId: state.myId,
      answer: answer
    });
  } catch (err) {
    console.error("SDP Answer generation error: ", err);
  }
}

async function handleSdpAnswer(peerId, answer) {
  const pc = state.peerConnections[peerId];
  if (pc) {
    try {
      await pc.setRemoteDescription(new RTCSessionDescription(answer));
    } catch (err) {
      console.error("SetRemoteDescription answer error: ", err);
    }
  }
}

async function handleIceCandidate(peerId, candidate) {
  const pc = state.peerConnections[peerId];
  if (pc) {
    try {
      await pc.addIceCandidate(new RTCIceCandidate(candidate));
    } catch (err) {
      console.error("AddIceCandidate error: ", err);
    }
  }
}

function handlePeerLeave(peerId) {
  const card = document.getElementById(`card-${peerId}`);
  if (card) {
    card.remove();
    updateGridSize();
    addSystemMessage(`El nodo se ha desconectado de la red.`);
    synth.playDisconnect();
  }

  if (state.peerConnections[peerId]) {
    state.peerConnections[peerId].close();
    delete state.peerConnections[peerId];
  }
}

// Generate UI card for remote participants
function createParticipantCard(peerId, name, stream) {
  let card = document.getElementById(`card-${peerId}`);
  if (card) return; // Avoid duplicate tiles

  card = document.createElement('div');
  card.id = `card-${peerId}`;
  card.className = 'participant-card';
  card.innerHTML = `
    <video class="video-viewport" autoplay playsinline></video>
    <div class="avatar-viewport hidden">
      <div class="avatar-wrapper">
        <div class="voice-ring"></div>
        <div class="avatar-placeholder">${name.substring(0,2).toUpperCase()}</div>
      </div>
    </div>
    <div class="hud-overlay">
      <div class="hud-top">
        <div class="user-name-badge">
          <span>${name}</span>
        </div>
        <div class="hud-status-indicator">
          <div id="badge-mic-${peerId}" class="status-badge hidden">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19 11h-1.7c0 .74-.16 1.43-.43 2.05l1.23 1.23c.56-.98.9-2.09.9-3.28zm-4.02.17l-11-11L2.7 1.45 6 4.75V11c0 3.28 2.72 6 6 6 .73 0 1.43-.13 2.07-.36l3.83 3.83 1.41-1.41-14.33-14.33z"/></svg>
          </div>
        </div>
      </div>
      <div class="hud-bottom">
        <span class="user-name-badge" style="font-size: 0.65rem; border-color: var(--neon-cyan); color: var(--neon-cyan);">
          ENLACE REMOTO
        </span>
      </div>
    </div>
    <!-- Visualizer overlay -->
    <div class="card-visualizer">
      <div class="visualizer-bar"></div>
      <div class="visualizer-bar"></div>
      <div class="visualizer-bar"></div>
      <div class="visualizer-bar"></div>
      <div class="visualizer-bar"></div>
      <div class="visualizer-bar"></div>
      <div class="visualizer-bar"></div>
    </div>
  `;

  participantsGrid.appendChild(card);
  const video = card.querySelector('video');
  video.srcObject = stream;

  // Add voice tracking visual simulation on remote video
  setupSpeakingAnimation(card);
  
  updateGridSize();
}

// Simulated speaking UI reactions (to visualizer overlay)
function setupSpeakingAnimation(cardEl) {
  let interval = setInterval(() => {
    if (!document.getElementById(cardEl.id)) {
      clearInterval(interval);
      return;
    }
    
    // Simulate speaking randomly unless bots/peers send explicit signals
    const speaking = Math.random() > 0.85;
    if (speaking) {
      cardEl.classList.add('speaking');
      const bars = cardEl.querySelectorAll('.visualizer-bar');
      bars.forEach(bar => {
        bar.style.height = `${Math.random() * 28 + 2}px`;
      });
    } else {
      cardEl.classList.remove('speaking');
    }
  }, 180);
}

// --- SIMULATED INTRUSION NODES (Bots) ---
function injectBot(template) {
  if (state.bots[template.id]) return;
  
  state.bots[template.id] = template;

  const card = document.createElement('div');
  card.id = `card-${template.id}`;
  card.className = 'participant-card';
  card.innerHTML = `
    <div class="avatar-viewport">
      <div class="avatar-wrapper" style="border-color: ${template.color}">
        <div class="voice-ring" style="border-color: ${template.color}"></div>
        <div class="avatar-placeholder" style="background: linear-gradient(135deg, ${template.color}50, ${template.color}15); color: ${template.color}">${template.letter}</div>
      </div>
    </div>
    <div class="hud-overlay">
      <div class="hud-top">
        <div class="user-name-badge">
          <span>${template.name}</span>
          <span class="badge-bot">BOT</span>
        </div>
        <div class="hud-status-indicator">
          <div id="badge-mic-${template.id}" class="status-badge hidden">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19 11h-1.7c0 .74-.16 1.43-.43 2.05l1.23 1.23c.56-.98.9-2.09.9-3.28zm-4.02.17l-11-11L2.7 1.45 6 4.75V11c0 3.28 2.72 6 6 6 .73 0 1.43-.13 2.07-.36l3.83 3.83 1.41-1.41-14.33-14.33z"/></svg>
          </div>
        </div>
      </div>
      <div class="hud-bottom">
        <span class="user-name-badge" style="font-size: 0.65rem; border-color: ${template.color}; color: ${template.color}">
          ESTADO: ${template.tag}
        </span>
      </div>
    </div>
    <!-- Visualizer overlay -->
    <div class="card-visualizer">
      <div class="visualizer-bar" style="background:${template.color}; box-shadow: 0 0 5px ${template.color}"></div>
      <div class="visualizer-bar" style="background:${template.color}; box-shadow: 0 0 5px ${template.color}"></div>
      <div class="visualizer-bar" style="background:${template.color}; box-shadow: 0 0 5px ${template.color}"></div>
      <div class="visualizer-bar" style="background:${template.color}; box-shadow: 0 0 5px ${template.color}"></div>
      <div class="visualizer-bar" style="background:${template.color}; box-shadow: 0 0 5px ${template.color}"></div>
      <div class="visualizer-bar" style="background:${template.color}; box-shadow: 0 0 5px ${template.color}"></div>
      <div class="visualizer-bar" style="background:${template.color}; box-shadow: 0 0 5px ${template.color}"></div>
    </div>
  `;

  participantsGrid.appendChild(card);
  updateGridSize();
  synth.playConnect();

  addSystemMessage(`NODO ENLACE: Inyectado ${template.name} en la red.`);

  // Sim chat message from Bot
  setTimeout(() => {
    sendBotChatMessage(template.name, getBotGreetings(template.letter));
  }, 1000);

  // Setup loop for speaking activity
  const speakInterval = setInterval(() => {
    if (!document.getElementById(`card-${template.id}`)) {
      clearInterval(speakInterval);
      return;
    }

    // Speak 30% of the time
    const isSpeaking = Math.random() > 0.7;
    const badgeMic = document.getElementById(`badge-mic-${template.id}`);
    
    if (isSpeaking) {
      card.classList.add('speaking');
      const bars = card.querySelectorAll('.visualizer-bar');
      bars.forEach(bar => {
        bar.style.height = `${Math.random() * 28 + 2}px`;
      });
      if (Math.random() > 0.96) {
        sendBotChatMessage(template.name, getBotRandomLine(template.letter));
      }
    } else {
      card.classList.remove('speaking');
    }
  }, 200);
}

function removeBot(botId) {
  const card = document.getElementById(`card-${botId}`);
  if (card) {
    card.remove();
    updateGridSize();
    addSystemMessage(`NODO ENLACE: Desvinculado ${state.bots[botId].name}.`);
    delete state.bots[botId];
    synth.playDisconnect();
  }
}

// Bot text generations
function getBotGreetings(letter) {
  switch (letter) {
    case 'A': return "Sistemas del canal cuántico inicializados. Monitoreando latencia de red.";
    case 'K': return "Enlace de frecuencia listo. Conexión configurada en banda submilimétrica.";
    case 'H': return "Recepción del satélite orbital conectada. Señal encriptada al 99.8%.";
    case 'N': return "Virtualizador cargado. Flujos de comunicación cuántica alineados.";
  }
  return "Señal de terminal online.";
}

function getBotRandomLine(letter) {
  const lines = [
    "Estado de red: Estable.",
    "Buscando flujos de datos en paralelo...",
    "Re-encaminando enlace por proxy local.",
    "Latencia del nodo corregida automáticamente.",
    "Nivel de modulación: nominal.",
    "Enlace redundante activado."
  ];
  return lines[Math.floor(Math.random() * lines.length)];
}

// --- TERMINAL CHAT SYSTEM ---
function addSystemMessage(text) {
  const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const msg = document.createElement('div');
  msg.className = 'chat-message chat-msg-system';
  msg.innerHTML = `
    <div class="chat-msg-header">
      <span class="chat-msg-author">SISTEMA</span>
      <span class="chat-msg-time">${time}</span>
    </div>
    <div class="chat-msg-content">${text}</div>
  `;
  chatMessages.appendChild(msg);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function sendBotChatMessage(botName, text) {
  const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const msg = document.createElement('div');
  msg.className = 'chat-message';
  msg.innerHTML = `
    <div class="chat-msg-header">
      <span class="chat-msg-author" style="color: var(--neon-purple)">${botName}</span>
      <span class="chat-msg-time">${time}</span>
    </div>
    <div class="chat-msg-content">${text}</div>
  `;
  chatMessages.appendChild(msg);
  chatMessages.scrollTop = chatMessages.scrollHeight;
  synth.playMessage();
}

function sendChatMessage(text) {
  if (!text.trim()) return;
  
  const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const msg = document.createElement('div');
  msg.className = 'chat-message';
  msg.innerHTML = `
    <div class="chat-msg-header">
      <span class="chat-msg-author">${state.username}</span>
      <span class="chat-msg-time">${time}</span>
    </div>
    <div class="chat-msg-content">${text}</div>
  `;
  chatMessages.appendChild(msg);
  chatMessages.scrollTop = chatMessages.scrollHeight;

  // Broadcast to other tabs via WebRTC / BroadcastChannel
  if (state.broadcastChannel) {
    state.broadcastChannel.postMessage({
      type: 'chat-broadcast',
      senderId: state.myId,
      username: state.username,
      message: text
    });
  }
  
  synth.playToggle(true);
}

function receiveChatMessage(author, text) {
  const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const msg = document.createElement('div');
  msg.className = 'chat-message';
  msg.innerHTML = `
    <div class="chat-msg-header">
      <span class="chat-msg-author" style="color: var(--neon-cyan)">${author}</span>
      <span class="chat-msg-time">${time}</span>
    </div>
    <div class="chat-msg-content">${text}</div>
  `;
  chatMessages.appendChild(msg);
  chatMessages.scrollTop = chatMessages.scrollHeight;
  synth.playMessage();
}

// Chat input listeners
chatSendBtn.addEventListener('click', () => {
  sendChatMessage(chatInput.value);
  chatInput.value = '';
});

chatInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    sendChatMessage(chatInput.value);
    chatInput.value = '';
  }
});

// --- CORE FUNCTIONAL ACTIONS ---
async function startSession(username, roomCode) {
  state.username = username || "Operador_Anon";
  state.roomCode = roomCode || "VOID-CORE";
  
  userDisplayName.innerText = state.username;
  activeRoomCode.innerText = state.roomCode.toUpperCase();
  
  // Hide join screen, display call panel
  joinScreen.classList.add('hidden');
  appShell.classList.remove('hidden');

  synth.playConnect();

  // Retrieve Camera/Microphone streams
  await setupLocalMedia();
  
  // Set up signaling
  initBroadcastSignaling();

  // Load telemetry graphics
  initTelemetryGraphs();
}

// --- BUTTON DECK LISTENERS ---

// Toggle Mic
btnToggleMic.addEventListener('click', () => {
  state.isMuted = !state.isMuted;
  
  // Toggle track mute
  if (state.localStream) {
    state.localStream.getAudioTracks().forEach(track => {
      track.enabled = !state.isMuted;
    });
  }

  // UI state change
  if (state.isMuted) {
    btnToggleMic.classList.add('muted');
    btnToggleMic.setAttribute('data-tooltip', 'Activar Micrófono');
    iconMic.classList.add('hidden');
    iconMicOff.classList.remove('hidden');
    document.getElementById(`badge-mic-local`).classList.remove('hidden');
    addSystemMessage("Audio local desactivado.");
  } else {
    btnToggleMic.classList.remove('muted');
    btnToggleMic.setAttribute('data-tooltip', 'Silenciar Micrófono');
    iconMic.classList.remove('hidden');
    iconMicOff.classList.add('hidden');
    document.getElementById(`badge-mic-local`).classList.add('hidden');
    addSystemMessage("Audio local reactivado.");
  }

  synth.playToggle(!state.isMuted);
});

// Toggle Camera
btnToggleCam.addEventListener('click', () => {
  state.isCamOff = !state.isCamOff;
  
  // Toggle track mute
  if (state.localStream) {
    state.localStream.getVideoTracks().forEach(track => {
      track.enabled = !state.isCamOff;
    });
  }

  const avatarLocal = document.getElementById('avatar-local');
  const videoLocal = document.getElementById('video-local');

  if (state.isCamOff) {
    btnToggleCam.classList.add('muted');
    btnToggleCam.setAttribute('data-tooltip', 'Encender Cámara');
    iconCam.classList.add('hidden');
    iconCamOff.classList.remove('hidden');
    avatarLocal.classList.remove('hidden');
    videoLocal.classList.add('hidden');
    addSystemMessage("Transmisión de cámara desactivada.");
  } else {
    btnToggleCam.classList.remove('muted');
    btnToggleCam.setAttribute('data-tooltip', 'Apagar Cámara');
    iconCam.classList.remove('hidden');
    iconCamOff.classList.add('hidden');
    avatarLocal.classList.add('hidden');
    videoLocal.classList.remove('hidden');
    addSystemMessage("Transmisión de cámara activa.");
  }

  synth.playToggle(!state.isCamOff);
});

// Screen sharing toggle
btnToggleScreen.addEventListener('click', async () => {
  if (!state.isScreenSharing) {
    // Start share
    try {
      const screenStream = await navigator.mediaDevices.getDisplayMedia({
        video: true
      });
      
      const videoTrack = screenStream.getVideoTracks()[0];
      
      // Update local card video stream object
      const localVideoEl = document.getElementById('video-local');
      localVideoEl.srcObject = screenStream;
      localVideoEl.classList.remove('mirrored'); // screen sharing shouldn't be mirrored
      localVideoEl.play().catch(e => console.log("Error playing screen share stream: ", e));

      // Make sure the local video element is visible and avatar is hidden during share
      const avatarLocal = document.getElementById('avatar-local');
      if (avatarLocal) avatarLocal.classList.add('hidden');
      localVideoEl.classList.remove('hidden');
      
      // Replace video tracks in RTCPeerConnections
      Object.values(state.peerConnections).forEach(pc => {
        const sender = pc.getSenders().find(s => s.track.kind === 'video');
        if (sender) sender.replaceTrack(videoTrack);
      });
      
      videoTrack.onended = () => {
        stopScreenShare();
      };

      state.isScreenSharing = true;
      btnToggleScreen.classList.add('muted');
      btnToggleScreen.setAttribute('data-tooltip', 'Detener Pantalla Compartida');
      addSystemMessage("Compartiendo pantalla local.");
      synth.playToggle(true);
      
    } catch (err) {
      console.warn("Could not start screen sharing: ", err);
      addSystemMessage("Fallo al iniciar el protocolo de pantalla compartida.");
    }
  } else {
    stopScreenShare();
  }
});

function stopScreenShare() {
  if (!state.isScreenSharing) return;

  const videoTrack = state.localStream.getVideoTracks()[0];
  
  // Revert video element track
  const localVideoEl = document.getElementById('video-local');
  localVideoEl.srcObject = state.localStream;
  localVideoEl.classList.add('mirrored');
  localVideoEl.play().catch(e => console.log("Error playing camera stream: ", e));
  
  // Restore visibility based on current camera toggle state
  const avatarLocal = document.getElementById('avatar-local');
  if (state.isCamOff) {
    if (avatarLocal) avatarLocal.classList.remove('hidden');
    localVideoEl.classList.add('hidden');
  } else {
    if (avatarLocal) avatarLocal.classList.add('hidden');
    localVideoEl.classList.remove('hidden');
  }

  // Replace video tracks in peer connections back to camera
  Object.values(state.peerConnections).forEach(pc => {
    const sender = pc.getSenders().find(s => s.track.kind === 'video');
    if (sender) sender.replaceTrack(videoTrack);
  });

  state.isScreenSharing = false;
  btnToggleScreen.classList.remove('muted');
  btnToggleScreen.setAttribute('data-tooltip', 'Compartir Pantalla');
  addSystemMessage("Pantalla compartida desactivada.");
  synth.playToggle(false);
}

// Master Chime/Volume slider adjustments
volSlider.addEventListener('input', (e) => {
  const val = e.target.value;
  synth.setVolume(val);
  
  // Scale sound simulation components
  const remoteVideos = document.querySelectorAll('.video-viewport:not(.mirrored)');
  remoteVideos.forEach(vid => {
    vid.volume = val / 100;
  });
});

// Disconnect from channel
btnDisconnect.addEventListener('click', () => {
  synth.playDisconnect();
  
  // Inform signaling
  if (state.broadcastChannel) {
    state.broadcastChannel.postMessage({
      type: 'peer-leave',
      senderId: state.myId
    });
    state.broadcastChannel.close();
  }

  // Clear peer connections
  Object.keys(state.peerConnections).forEach(peerId => {
    state.peerConnections[peerId].close();
  });
  state.peerConnections = {};

  // Stop camera media streams
  if (state.localStream) {
    state.localStream.getTracks().forEach(track => track.stop());
  }
  if (fallbackCanvasInterval) {
    clearInterval(fallbackCanvasInterval);
  }

  // Reset grid
  participantsGrid.innerHTML = '';
  state.bots = {};
  
  // Return to setup layout
  appShell.classList.add('hidden');
  joinScreen.classList.remove('hidden');
  addSystemMessage("Enlace desvinculado voluntariamente.");
});

// Click Room Badge to Copy
activeRoomCode.addEventListener('click', () => {
  navigator.clipboard.writeText(state.roomCode.trim().toUpperCase()).then(() => {
    addSystemMessage("CÓDIGO DE ENLACE COPIADO AL PORTAPAPELES. Transmítelo a otros terminales.");
    synth.playToggle(true);
  });
});

// Action buttons to launch sessions
joinCallBtn.addEventListener('click', () => {
  startSession(usernameInput.value, roomInput.value);
});

quickDemoBtn.addEventListener('click', () => {
  state.isDemoMode = true;
  startSession(usernameInput.value, roomInput.value).then(() => {
    // Inject first two bots after a brief moment
    setTimeout(() => injectBot(BOT_TEMPLATES[0]), 800);
    setTimeout(() => injectBot(BOT_TEMPLATES[1]), 1800);
  });
});
